import type { Metadata } from 'next'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { ThemeProvider } from '@/components/ThemeProvider'

export const metadata: Metadata = {
  metadataBase: new URL('https://toolhubpro.com'),
  title: {
    default: 'ToolHub Pro — 50+ Free Online Tools for Developers & Writers',
    template: '%s | ToolHub Pro',
  },
  description:
    'Free online tools for developers, writers, and SEO pros. JSON formatter, word counter, password generator, Base64 encoder & 50+ more. No signup. 100% in-browser.',
  keywords: [
    'free online tools', 'developer tools', 'seo tools', 'text tools',
    'json formatter', 'word counter', 'password generator', 'base64 encoder',
  ],
  authors: [{ name: 'ToolHub Pro' }],
  creator: 'ToolHub Pro',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://toolhubpro.com',
    siteName: 'ToolHub Pro',
    title: 'ToolHub Pro — 50+ Free Online Tools',
    description: 'Free browser-based tools for developers, writers, and SEO professionals.',
    images: [{ url: '/og/home.png', width: 1200, height: 630, alt: 'ToolHub Pro' }],
  },
  twitter: {
    card: 'summary_large_image',
    site: '@toolhubpro',
    creator: '@toolhubpro',
  },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true } },
  alternates: { canonical: 'https://toolhubpro.com' },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <script
          dangerouslySetInnerHTML={{
            __html: `
              try {
                const t = localStorage.getItem('theme')
                if (t === 'dark' || (!t && window.matchMedia('(prefers-color-scheme: dark)').matches))
                  document.documentElement.classList.add('dark')
              } catch {}
            `,
          }}
        />
      </head>
      <body className="bg-[#f5f7f6] text-gray-900 min-h-screen flex flex-col">
        <ThemeProvider>
          <Header />
          <main className="flex-1">{children}</main>
          <Footer />
        </ThemeProvider>
      </body>
    </html>
  )
}
