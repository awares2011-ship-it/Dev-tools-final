'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { TOOLS, CATEGORIES } from '@/lib/tools'
import { BLOGS } from '@/lib/blogs'
import ToolCard from '@/components/ToolCard'
import BlogCard from '@/components/BlogCard'
import AdBanner from '@/components/AdBanner'
import { ACCENT_HEX } from '@/lib/colors'

const GREEN_SHADES = ['#16a34a','#059669','#0d9488','#15803d','#4ade80','#34d399']

export default function HomePage() {
  const [query, setQuery] = useState('')
  const [activeCategory, setActiveCategory] = useState('all')
  const [displayed, setDisplayed] = useState(TOOLS)

  useEffect(() => {
    const params = new URLSearchParams(window.location.search)
    const q = params.get('q'); if (q) setQuery(q)
  }, [])

  useEffect(() => {
    let res = TOOLS
    if (activeCategory !== 'all') res = res.filter(t => t.category === activeCategory)
    if (query.trim()) {
      const q = query.toLowerCase()
      res = res.filter(t =>
        t.name.toLowerCase().includes(q) ||
        t.shortDesc.toLowerCase().includes(q) ||
        t.category.toLowerCase().includes(q) ||
        t.keywords.some(k => k.includes(q))
      )
    }
    setDisplayed(res)
  }, [query, activeCategory])

  const heroWords = ['Free','Online','Tools','for','Developers,','Writers','&','SEO Pros']

  return (
    <>
      {/* ── HERO ── */}
      <section className="relative overflow-hidden bg-gradient-to-br from-[#f5f7f6] to-[#e6f4ea] py-16 sm:py-20 text-center px-4">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute -top-24 -left-24 w-96 h-96 rounded-full opacity-[0.08] blur-3xl" style={{background:'#16a34a'}}/>
          <div className="absolute top-0 right-0 w-80 h-80 rounded-full opacity-[0.06] blur-3xl" style={{background:'#059669'}}/>
        </div>
        <div className="inline-flex items-center gap-2 bg-green-50 text-green-700 text-[11px] font-bold uppercase tracking-widest px-4 py-1.5 rounded-full mb-6 border border-green-200">
          ⚡ 50+ Free Tools · No Signup · 100% In-Browser
        </div>
        <h1 className="text-4xl sm:text-5xl lg:text-[3.5rem] font-extrabold leading-tight tracking-tight mb-4 max-w-4xl mx-auto">
          {heroWords.map((w,i)=>(
            <span key={i} className="inline-block mr-2 hover:scale-105 transition-transform" style={i%2===0?{color:GREEN_SHADES[Math.floor(i/2)%GREEN_SHADES.length]}:{}}>{w}</span>
          ))}
        </h1>
        <p className="text-gray-600 max-w-xl mx-auto mb-8 text-lg font-medium">Format JSON, generate passwords, count words, convert files & more — all free, instant, and private.</p>
        <div className="relative max-w-lg mx-auto mb-10">
          <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-lg">🔍</span>
          <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search 50+ tools — try JSON, password, slug…"
            className="w-full pl-11 pr-10 py-4 rounded-2xl border-2 border-gray-200 bg-white text-gray-900 text-[15px] focus:outline-none focus:border-green-400 shadow-sm transition-all"/>
          {query && <button onClick={()=>setQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 text-xl">×</button>}
        </div>
        <div className="flex flex-wrap justify-center gap-8">
          {[{n:'50+',l:'Free Tools',c:'#16a34a'},{n:'100%',l:'Client-Side',c:'#059669'},{n:'0',l:'Signup Needed',c:'#0d9488'},{n:'20+',l:'Blog Articles',c:'#15803d'}].map(s=>(
            <div key={s.l} className="text-center"><div className="text-2xl font-extrabold" style={{color:s.c}}>{s.n}</div><div className="text-xs text-gray-500 mt-0.5">{s.l}</div></div>
          ))}
        </div>
      </section>

      {/* ── AD ── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 my-4"><AdBanner slot="1234567890" format="horizontal"/></div>

      {/* ── CATEGORY PILLS ── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4">
        <div className="flex flex-wrap gap-2">
          {[{id:'all',name:'All Tools',icon:'🛠️',color:'green' as const},...CATEGORIES].map(cat=>{
            const accent = cat.id==='all' ? '#16a34a' : (ACCENT_HEX[(cat as any).color] ?? '#16a34a')
            const isActive = activeCategory === cat.id
            return (
              <button key={cat.id} onClick={()=>setActiveCategory(cat.id)}
                className="px-4 py-1.5 rounded-full text-sm font-semibold border-2 transition-all duration-200 hover:-translate-y-0.5"
                style={isActive ? {background:accent,color:'#fff',borderColor:accent} : {background:'white',borderColor:'#e5e7eb',color:'#6b7280'}}>
                {cat.icon} {cat.name.replace(' Tools','')}
              </button>
            )
          })}
        </div>
      </div>

      {/* ── TOOL GRID ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-12">
        <div className="flex items-center justify-between mb-4">
          <h2 className="font-bold text-gray-900 text-lg">
            {activeCategory==='all' ? '🛠️ All Tools' : `${CATEGORIES.find(c=>c.id===activeCategory)?.icon} ${CATEGORIES.find(c=>c.id===activeCategory)?.name}`}
            <span className="ml-2 text-gray-400 font-normal text-sm">({displayed.length})</span>
          </h2>
        </div>
        {displayed.length===0 ? (
          <div className="text-center py-20 text-gray-400">
            <div className="text-4xl mb-3">🔍</div>
            <p className="font-medium text-gray-700">No tools found for &quot;{query}&quot;</p>
            <button onClick={()=>{setQuery('');setActiveCategory('all')}} className="mt-3 text-sm text-green-600 hover:underline font-medium">Clear search</button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {displayed.map(tool=><ToolCard key={tool.id} tool={tool}/>)}
          </div>
        )}
      </section>

      {/* ── CATEGORY CARDS ── */}
      <section className="bg-gradient-to-br from-[#f5f7f6] to-[#e6f4ea] border-y border-gray-200 py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <h2 className="section-title mb-6">Browse by Category</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {CATEGORIES.map(cat=>{
              const accent = ACCENT_HEX[cat.color]
              return (
                <Link key={cat.id} href={`/tools/category/${cat.id}`}>
                  <div className="bg-white border border-gray-200 rounded-xl p-5 flex items-center gap-4 group shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200" style={{borderLeft:`4px solid ${accent}`}}>
                    <span className="text-3xl group-hover:scale-110 transition-transform">{cat.icon}</span>
                    <div>
                      <h3 className="font-bold text-sm text-gray-900 group-hover:text-green-600 transition-colors duration-200">{cat.name}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">{TOOLS.filter(t=>t.category===cat.id).length} tools available</p>
                    </div>
                  </div>
                </Link>
              )
            })}
          </div>
        </div>
      </section>

      {/* ── AD MID ── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 my-8"><AdBanner slot="0987654321" format="horizontal"/></div>

      {/* ── BLOG PREVIEW ── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 pb-16">
        <div className="section-header">
          <div>
            <h2 className="section-title">📝 Latest Articles &amp; Guides</h2>
            <p className="text-sm text-gray-500 mt-1">Deep dives, tutorials, and SEO tips</p>
          </div>
          <Link href="/blog" className="text-sm font-semibold text-green-600 hover:text-green-700 transition-colors">View all →</Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {BLOGS.slice(0,6).map(blog=><BlogCard key={blog.id} blog={blog}/>)}
        </div>
      </section>

      {/* ── WHY US ── */}
      <section className="bg-gradient-to-br from-[#f5f7f6] to-[#e6f4ea] border-t border-gray-200 py-14">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <h2 className="text-2xl font-extrabold mb-2 text-gray-900">
            Why <span className="text-green-600">ToolHub</span> <span className="text-gray-700">Pro</span>?
          </h2>
          <p className="text-gray-500 mb-10 font-medium">Built for speed, privacy, and simplicity.</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-5">
            {[
              {icon:'🔒',title:'100% Private',desc:'All processing in your browser. Zero data sent to servers.',color:'#16a34a'},
              {icon:'⚡',title:'Instant Results',desc:'No loading spinners. Tools respond in milliseconds.',color:'#059669'},
              {icon:'📱',title:'Mobile Ready',desc:'Fully responsive. Works on phones, tablets, and desktops.',color:'#0d9488'},
              {icon:'🎯',title:'No Signup',desc:'Use every tool immediately. No account, no email needed.',color:'#15803d'},
            ].map(f=>(
              <div key={f.title} className="bg-white rounded-xl p-5 border border-gray-200 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-200">
                <div className="text-3xl mb-3">{f.icon}</div>
                <h3 className="font-bold text-sm mb-1" style={{color:f.color}}>{f.title}</h3>
                <p className="text-xs text-gray-500 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── AD BOTTOM ── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 my-8"><AdBanner slot="1122334455" format="horizontal"/></div>

      <script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify({
        '@context':'https://schema.org','@type':'WebSite','name':'ToolHub Pro',
        'url':'https://toolhubpro.com','description':'Free online tools for developers, writers, and SEO professionals.',
        potentialAction:{'@type':'SearchAction','target':'https://toolhubpro.com/?q={search_term_string}','query-input':'required name=search_term_string'}
      })}}/>
    </>
  )
}
