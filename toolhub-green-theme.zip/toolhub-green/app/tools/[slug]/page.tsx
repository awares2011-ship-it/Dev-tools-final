import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { TOOLS, getToolById, getRelatedTools } from '@/lib/tools'
import { BLOGS, getBlogsByTool } from '@/lib/blogs'
import { ACCENT_HEX } from '@/lib/colors'
import AdBanner from '@/components/AdBanner'
import FAQSection from '@/components/FAQSection'
import ToolCard from '@/components/ToolCard'
import BlogCard from '@/components/BlogCard'
import ToolEngine from '@/components/tools/ToolEngine'

export function generateStaticParams() {
  return TOOLS.map(t => ({ slug: t.id }))
}

export function generateMetadata({ params }: { params: { slug: string } }): Metadata {
  const tool = getToolById(params.slug)
  if (!tool) return {}
  return {
    title: `${tool.name} — Free Online Tool`,
    description: tool.longDesc.slice(0, 160),
    keywords: tool.keywords,
    openGraph: { title: `${tool.name} | ToolHub Pro`, description: tool.shortDesc, type: 'website' },
    alternates: { canonical: `https://toolhubpro.com/tools/${tool.id}` },
  }
}

export default function ToolPage({ params }: { params: { slug: string } }) {
  const tool = getToolById(params.slug)
  if (!tool) notFound()
  const related = getRelatedTools(tool)
  const blogs = getBlogsByTool(tool.id)
  const popularTools = TOOLS.filter(t => t.id !== tool.id).slice(0, 6)
  const accent = ACCENT_HEX[tool.color]

  const schema = {
    '@context': 'https://schema.org', '@type': 'WebApplication',
    name: tool.name, description: tool.longDesc,
    url: `https://toolhubpro.com/tools/${tool.id}`,
    applicationCategory: 'UtilitiesApplication', operatingSystem: 'Web Browser',
    offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
  }

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        <nav className="breadcrumb mb-6">
          <Link href="/">Home</Link><span>/</span>
          <Link href={`/tools/category/${tool.category}`}>{tool.category}</Link><span>/</span>
          <span className="text-green-600">{tool.name}</span>
        </nav>
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-4xl">{tool.icon}</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">{tool.name}</h1>
            <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-green-50 text-green-700 border border-green-200">Free</span>
          </div>
          <p className="text-gray-600 max-w-2xl font-medium">{tool.longDesc}</p>
        </div>
        <AdBanner slot="tool-top" format="horizontal" className="mb-6" />
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_280px] gap-6">
          <div><ToolEngine toolId={tool.id} accent={accent} /></div>
          <aside className="flex flex-col gap-4">
            {related.length > 0 && (
              <div className="tool-box">
                <h3 className="font-bold text-sm text-gray-900 mb-3">🔗 Related Tools</h3>
                {related.map(rt => (
                  <Link key={rt.id} href={`/tools/${rt.id}`} className="flex items-center gap-2.5 py-2 px-2 rounded-lg hover:bg-gray-50 transition-colors group">
                    <span className="w-2 h-2 rounded-full shrink-0" style={{ background: ACCENT_HEX[rt.color] }} />
                    <span className="text-sm font-medium text-gray-700 group-hover:text-green-600 transition-colors">{rt.name}</span>
                  </Link>
                ))}
              </div>
            )}
            {blogs.length > 0 && (
              <div className="tool-box">
                <h3 className="font-bold text-sm text-gray-900 mb-3">📝 Learn More</h3>
                {blogs.map(b => (
                  <Link key={b.id} href={`/blog/${b.id}`} className="flex items-start gap-2 py-2 px-2 rounded-lg hover:bg-gray-50 transition-colors group mb-1">
                    <span className="text-gray-400 mt-0.5 shrink-0">→</span>
                    <span className="text-sm text-gray-700 group-hover:text-green-600 transition-colors leading-snug">{b.title}</span>
                  </Link>
                ))}
              </div>
            )}
            <AdBanner slot="tool-sidebar" format="rectangle" />
            <div className="tool-box">
              <h3 className="font-bold text-sm text-gray-900 mb-3">⭐ Popular Tools</h3>
              {popularTools.map(pt => (
                <Link key={pt.id} href={`/tools/${pt.id}`} className="flex items-center gap-2.5 py-2 px-2 rounded-lg hover:bg-gray-50 transition-colors group">
                  <span className="text-base">{pt.icon}</span>
                  <span className="text-sm font-medium text-gray-700 group-hover:text-green-600 transition-colors">{pt.name}</span>
                </Link>
              ))}
            </div>
          </aside>
        </div>
        <AdBanner slot="tool-after" format="horizontal" className="mt-8" />
        <div className="mt-10 grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 seo-prose">
            <h2>What is {tool.name}?</h2>
            <p>{tool.longDesc}</p>
            <p>This tool runs entirely in your browser — your data is <strong>never</strong> sent to any server. Complete privacy, works offline after first load.</p>
            <h2>How to Use {tool.name}</h2>
            <p>Paste or type your input, click the action button, and results appear instantly. Copy output to clipboard or download as a file.</p>
            <ul>
              <li>No installation or plugins required</li>
              <li>Works on all modern browsers (Chrome, Firefox, Safari, Edge)</li>
              <li>Mobile-friendly responsive design</li>
              <li>Process unlimited data — no rate limits</li>
            </ul>
            <h2>Frequently Asked Questions</h2>
            <FAQSection faqs={tool.faqs} toolName={tool.name} />
          </div>
          <div className="space-y-4">
            <Link href={`/tools/category/${tool.category}`} className="tool-box block hover:shadow-md transition-all duration-200 hover:-translate-y-0.5">
              <h3 className="font-bold text-sm mb-1 text-green-600">🗂️ Browse {tool.category} Tools</h3>
              <p className="text-xs text-gray-500">See all {TOOLS.filter(t=>t.category===tool.category).length} tools in this category</p>
            </Link>
            <div className="tool-box">
              <h3 className="font-bold text-sm text-gray-900 mb-3">🏷️ Keywords</h3>
              <div className="flex flex-wrap gap-1.5">
                {tool.keywords.map(k => (
                  <span key={k} className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-green-50 text-green-700">{k}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
        {blogs.length > 0 && (
          <div className="mt-12">
            <h2 className="section-title mb-5">📚 Related Guides</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {blogs.map(b => <BlogCard key={b.id} blog={b} />)}
            </div>
          </div>
        )}
        <div className="mt-12">
          <h2 className="section-title mb-5">🛠️ More {tool.category} Tools</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {TOOLS.filter(t=>t.id!==tool.id&&t.category===tool.category).slice(0,4).map(t=><ToolCard key={t.id} tool={t}/>)}
          </div>
          <div className="text-center mt-6">
            <Link href="/" className="btn-ghost btn">
              View all 50+ free tools →
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}
