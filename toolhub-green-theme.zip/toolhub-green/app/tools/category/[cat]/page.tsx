import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import Link from 'next/link'
import { TOOLS, CATEGORIES, getToolsByCategory } from '@/lib/tools'
import { ACCENT_HEX } from '@/lib/colors'
import ToolCard from '@/components/ToolCard'
import AdBanner from '@/components/AdBanner'

export function generateStaticParams() {
  return CATEGORIES.map(c => ({ cat: c.id }))
}
export function generateMetadata({ params }: { params: { cat: string } }): Metadata {
  const cat = CATEGORIES.find(c => c.id === params.cat)
  if (!cat) return {}
  return { title: `${cat.name} — Free Online Tools`, description: cat.desc }
}

export default function CategoryPage({ params }: { params: { cat: string } }) {
  const cat = CATEGORIES.find(c => c.id === params.cat)
  if (!cat) notFound()
  const tools = getToolsByCategory(cat.id as any)
  const accent = ACCENT_HEX[cat.color]
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10">
      <nav className="breadcrumb mb-6">
        <Link href="/">Home</Link><span>/</span><span className="text-green-600">{cat.name}</span>
      </nav>
      <div className="flex items-center gap-4 mb-6">
        <span className="text-5xl">{cat.icon}</span>
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-gray-900">{cat.name}</h1>
          <p className="text-gray-500 mt-1 font-medium">{tools.length} free tools · {cat.desc}</p>
        </div>
      </div>
      <AdBanner slot="cat-top" format="horizontal" className="mb-8" />
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {tools.map(tool => <ToolCard key={tool.id} tool={tool} />)}
      </div>
      <div className="mt-12">
        <h2 className="text-lg font-bold text-gray-900 mb-4">Other Categories</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {CATEGORIES.filter(c=>c.id!==cat.id).map(c=>{
            const a = ACCENT_HEX[c.color]
            return (
              <Link key={c.id} href={`/tools/category/${c.id}`}>
                <div className="tool-box flex items-center gap-3 group hover:shadow-md hover:-translate-y-0.5 transition-all duration-200" style={{borderLeft:`3px solid ${a}`}}>
                  <span className="text-2xl">{c.icon}</span>
                  <div>
                    <div className="font-bold text-sm text-gray-900 group-hover:text-green-600 transition-colors duration-200">{c.name}</div>
                    <div className="text-xs text-gray-500">{TOOLS.filter(t=>t.category===c.id).length} tools</div>
                  </div>
                </div>
              </Link>
            )
          })}
        </div>
      </div>
    </div>
  )
}
