'use client'
import { useEffect, useRef } from 'react'

interface AdBannerProps {
  slot?: string
  format?: 'horizontal' | 'rectangle' | 'vertical'
  className?: string
}

const SIZE_MAP = {
  horizontal: 'h-[90px]',
  rectangle:  'h-[250px]',
  vertical:   'h-[600px]',
}

export default function AdBanner({ slot, format = 'horizontal', className = '' }: AdBannerProps) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // In production, replace with real AdSense code:
    // const adsbygoogle = (window as any).adsbygoogle || []
    // adsbygoogle.push({})
  }, [])

  return (
    <div
      ref={ref}
      className={`ad-slot ${SIZE_MAP[format]} ${className}`}
      aria-label="Advertisement"
      data-ad-slot={slot}
    >
      <div className="flex flex-col items-center gap-1">
        <span className="text-[10px]">ADVERTISEMENT</span>
        {/* Production AdSense:
        <ins
          className="adsbygoogle"
          style={{ display: 'block' }}
          data-ad-client="ca-pub-XXXXXXXXXX"
          data-ad-slot={slot}
          data-ad-format="auto"
          data-full-width-responsive="true"
        /> */}
      </div>
    </div>
  )
}
