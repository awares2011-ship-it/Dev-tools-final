import Link from 'next/link'
import { TOOLS, CATEGORIES } from '@/lib/tools'
import { BLOGS } from '@/lib/blogs'

export default function Footer() {
  const popular = TOOLS.slice(0, 8)
  const recentBlogs = BLOGS.slice(0, 5)

  return (
    <footer className="bg-gray-50 border-t border-gray-200 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12">
        {/* Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-10">

          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-3">
              <span className="w-7 h-7 rounded-lg bg-green-50 border border-green-200 flex items-center justify-center text-sm font-black text-green-600">⚡</span>
              <span className="font-extrabold text-gray-900 text-[15px]">
                Tool<span className="text-green-600">Hub</span>
                <span className="text-gray-500"> Pro</span>
              </span>
            </Link>
            <p className="text-sm text-gray-500 leading-relaxed">
              Free online tools for developers, writers, and SEO professionals. No signup, no tracking.
            </p>
            <div className="flex gap-2 mt-4">
              {['🐦 Twitter', '📧 Email'].map(s => (
                <span key={s} className="text-xs bg-white border border-gray-200 px-3 py-1.5 rounded-lg text-gray-600 cursor-pointer hover:border-green-300 hover:text-green-700 transition-colors duration-200">
                  {s}
                </span>
              ))}
            </div>
          </div>

          {/* Popular Tools */}
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider text-gray-400 mb-3">Popular Tools</h3>
            <ul className="space-y-2">
              {popular.map(t => (
                <li key={t.id}>
                  <Link href={`/tools/${t.id}`} className="text-sm text-gray-600 hover:text-green-600 transition-colors duration-200">
                    {t.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider text-gray-400 mb-3">Categories</h3>
            <ul className="space-y-2">
              {CATEGORIES.map(c => (
                <li key={c.id}>
                  <Link href={`/tools/category/${c.id}`} className="text-sm text-gray-600 hover:text-green-600 transition-colors duration-200">
                    {c.icon} {c.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Blog & Pages */}
          <div>
            <h3 className="font-bold text-xs uppercase tracking-wider text-gray-400 mb-3">Latest Articles</h3>
            <ul className="space-y-2 mb-6">
              {recentBlogs.map(b => (
                <li key={b.id}>
                  <Link href={`/blog/${b.id}`} className="text-sm text-gray-600 hover:text-green-600 transition-colors duration-200 line-clamp-1">
                    {b.title}
                  </Link>
                </li>
              ))}
            </ul>
            <h3 className="font-bold text-xs uppercase tracking-wider text-gray-400 mb-3">Pages</h3>
            <ul className="space-y-2">
              {[
                { href: '/about', label: 'About Us' },
                { href: '/contact', label: 'Contact' },
                { href: '/privacy-policy', label: 'Privacy Policy' },
                { href: '/disclaimer', label: 'Disclaimer' },
              ].map(p => (
                <li key={p.href}>
                  <Link href={p.href} className="text-sm text-gray-600 hover:text-gray-900 transition-colors duration-200">
                    {p.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* SEO tag cloud */}
        <div className="border-t border-gray-200 pt-8 mb-6">
          <h3 className="font-bold text-xs uppercase tracking-wider text-gray-400 mb-3">Explore All Tools</h3>
          <div className="flex flex-wrap gap-2">
            {TOOLS.map(t => (
              <Link
                key={t.id}
                href={`/tools/${t.id}`}
                className="text-xs bg-white border border-gray-200 px-2.5 py-1 rounded-lg text-gray-600 hover:border-green-300 hover:text-green-700 transition-colors duration-200"
              >
                {t.name}
              </Link>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-gray-200 pt-6 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p className="text-xs text-gray-400">© {new Date().getFullYear()} ToolHub Pro. All rights reserved.</p>
          <div className="flex gap-4 text-xs text-gray-400">
            <Link href="/sitemap.xml" className="hover:text-gray-600 transition-colors">Sitemap</Link>
            <Link href="/robots.txt" className="hover:text-gray-600 transition-colors">Robots.txt</Link>
            <span>Built with ❤️ — Free forever</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
