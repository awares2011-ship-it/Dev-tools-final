'use client'
import { useState } from 'react'
import Link from 'next/link'
import { useTheme } from './ThemeProvider'
import { CATEGORIES } from '@/lib/tools'

export default function Header() {
  const { theme, toggle } = useTheme()
  const [menuOpen, setMenuOpen] = useState(false)
  const [search, setSearch] = useState('')

  return (
    <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center gap-4">

        {/* Logo */}
        <Link href="/" className="flex items-center gap-2 shrink-0 group">
          <span className="w-7 h-7 rounded-lg bg-green-50 border border-green-200 flex items-center justify-center text-sm font-black text-green-600 group-hover:scale-105 transition-transform">⚡</span>
          <span className="font-extrabold text-gray-900 text-[15px] tracking-tight">
            Tool<span className="text-green-600">Hub</span>
            <span className="text-gray-500"> Pro</span>
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-0.5 flex-1">
          {CATEGORIES.map(cat => (
            <Link
              key={cat.id}
              href={`/tools/category/${cat.id}`}
              className="px-3 py-1.5 text-[13px] font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-all duration-200"
            >
              {cat.icon} {cat.name.replace(' Tools', '')}
            </Link>
          ))}
          <Link
            href="/blog"
            className="px-3 py-1.5 text-[13px] font-medium text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-all duration-200"
          >
            📝 Blog
          </Link>
        </nav>

        {/* Search */}
        <div className="hidden sm:flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl px-3 py-1.5 w-48 lg:w-60 focus-within:border-green-400 transition-colors">
          <span className="text-gray-400 text-sm">🔍</span>
          <input
            value={search}
            onChange={e => setSearch(e.target.value)}
            onKeyDown={e => {
              if (e.key === 'Enter' && search.trim()) {
                window.location.href = `/?q=${encodeURIComponent(search.trim())}`
              }
            }}
            placeholder="Search tools…"
            className="bg-transparent text-[13px] outline-none text-gray-700 placeholder-gray-400 w-full"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center gap-1.5 ml-auto">
          <button
            onClick={toggle}
            className="w-8 h-8 rounded-lg border border-gray-200 bg-gray-50 hover:bg-gray-100 flex items-center justify-center text-sm transition-all duration-200"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>
          <button
            className="md:hidden w-8 h-8 rounded-lg border border-gray-200 bg-gray-50 flex items-center justify-center text-sm"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Menu"
          >
            ☰
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div className="md:hidden border-t border-gray-200 bg-white px-4 py-3 flex flex-col gap-1">
          {CATEGORIES.map(cat => (
            <Link
              key={cat.id}
              href={`/tools/category/${cat.id}`}
              onClick={() => setMenuOpen(false)}
              className="px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-green-700 rounded-lg transition-all duration-200"
            >
              {cat.icon} {cat.name}
            </Link>
          ))}
          <Link
            href="/blog"
            onClick={() => setMenuOpen(false)}
            className="px-3 py-2 text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-green-700 rounded-lg transition-all duration-200"
          >
            📝 Blog
          </Link>
          <div className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-xl px-3 py-2 mt-1">
            <span className="text-gray-400 text-sm">🔍</span>
            <input
              placeholder="Search tools…"
              className="bg-transparent text-sm outline-none text-gray-700 placeholder-gray-400 w-full"
            />
          </div>
        </div>
      )}
    </header>
  )
}
