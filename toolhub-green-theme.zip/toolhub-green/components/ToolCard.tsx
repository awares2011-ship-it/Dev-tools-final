import Link from 'next/link'
import type { Tool } from '@/lib/tools'
import { ACCENT_HEX } from '@/lib/colors'

export default function ToolCard({ tool }: { tool: Tool }) {
  const accent = ACCENT_HEX[tool.color]

  return (
    <Link href={`/tools/${tool.id}`}>
      <article
        className="tool-card group h-full"
        style={{ borderTop: `3px solid ${accent}` }}
      >
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center text-xl mb-3 transition-transform group-hover:scale-110"
          style={{ background: `${accent}18` }}
        >
          {tool.icon}
        </div>
        <h3 className="font-bold text-sm text-gray-900 mb-1 leading-snug group-hover:text-green-600 transition-colors duration-200">
          {tool.name}
        </h3>
        <p className="text-xs text-gray-500 leading-relaxed mb-3">
          {tool.shortDesc}
        </p>
        <span
          className="inline-block text-[11px] font-semibold px-2 py-0.5 rounded-md"
          style={{ background: `${accent}15`, color: accent }}
        >
          {tool.category}
        </span>
      </article>
    </Link>
  )
}
