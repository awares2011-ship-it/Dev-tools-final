'use client'
import { useState } from 'react'

export default function JsonFormatter({ accent }: { accent: string }) {
  const [input, setInput] = useState('')
  const [output, setOutput] = useState('')
  const [error, setError] = useState('')
  const [indent, setIndent] = useState('2')

  const format = () => {
    setError('')
    try {
      const parsed = JSON.parse(input)
      setOutput(JSON.stringify(parsed, null, parseInt(indent)))
    } catch (e: any) {
      setError(e.message)
      setOutput('')
    }
  }
  const minify = () => {
    setError('')
    try { setOutput(JSON.stringify(JSON.parse(input))) }
    catch (e: any) { setError(e.message) }
  }
  const validate = () => {
    try { JSON.parse(input); setOutput('✅ Valid JSON — No errors found!'); setError('') }
    catch (e: any) { setError(e.message); setOutput('') }
  }
  const copy = () => navigator.clipboard.writeText(output).then(() => alert('Copied!'))
  const download = () => {
    const a = document.createElement('a')
    a.href = 'data:text/plain;charset=utf-8,' + encodeURIComponent(output)
    a.download = 'formatted.json'; a.click()
  }

  return (
    <div className="space-y-4">
      <div className="tool-box">
        <label className="form-label">JSON Input</label>
        <textarea value={input} onChange={e => setInput(e.target.value)}
          className="tool-input" rows={7}
          placeholder='{"name":"ToolHub Pro","version":1,"tools":["JSON","Base64","Password"]}' />
        <div className="flex gap-2 mt-3 flex-wrap items-center">
          <button onClick={format} className="btn btn-teal">✨ Format</button>
          <button onClick={minify} className="btn btn-ghost">🔧 Minify</button>
          <button onClick={validate} className="btn btn-ghost">✅ Validate</button>
          <select value={indent} onChange={e => setIndent(e.target.value)}
            className="form-select w-28 ml-auto">
            <option value="2">2 spaces</option>
            <option value="4">4 spaces</option>
            <option value="1">1 space</option>
          </select>
          <button onClick={() => { setInput(''); setOutput(''); setError('') }}
            className="btn btn-ghost">Clear</button>
        </div>
      </div>
      {error && (
        <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl px-4 py-3 text-sm text-red-700 dark:text-red-400">
          ❌ {error}
        </div>
      )}
      {output && (
        <div className="tool-box">
          <label className="form-label">Output</label>
          <pre className="tool-output text-xs leading-relaxed overflow-x-auto">{output}</pre>
          <div className="flex gap-2 mt-3">
            <button onClick={copy} className="btn btn-ghost btn-sm">📋 Copy</button>
            <button onClick={download} className="btn btn-ghost btn-sm">⬇️ Download</button>
          </div>
        </div>
      )}
    </div>
  )
}
