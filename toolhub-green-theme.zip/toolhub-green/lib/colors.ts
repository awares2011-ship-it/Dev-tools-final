import type { ColorKey } from './tools'

export const COLOR_MAP: Record<ColorKey, {
  bg: string; text: string; accent: string; border: string; badge: string; ring: string
}> = {
  purple: {
    bg: 'bg-purple-50 dark:bg-purple-900/20',
    text: 'text-purple-800 dark:text-purple-200',
    accent: 'text-purple-600 dark:text-purple-400',
    border: 'border-purple-200 dark:border-purple-800',
    badge: 'bg-purple-50 text-purple-800 dark:bg-purple-900/40 dark:text-purple-200',
    ring: 'ring-purple-400',
  },
  teal: {
    bg: 'bg-teal-50 dark:bg-teal-900/20',
    text: 'text-teal-800 dark:text-teal-200',
    accent: 'text-teal-600 dark:text-teal-400',
    border: 'border-teal-200 dark:border-teal-800',
    badge: 'bg-teal-50 text-teal-800 dark:bg-teal-900/40 dark:text-teal-200',
    ring: 'ring-teal-400',
  },
  coral: {
    bg: 'bg-coral-50 dark:bg-coral-900/20',
    text: 'text-coral-800 dark:text-coral-200',
    accent: 'text-coral-600 dark:text-coral-400',
    border: 'border-coral-200 dark:border-coral-800',
    badge: 'bg-coral-50 text-coral-800 dark:bg-coral-900/40 dark:text-coral-200',
    ring: 'ring-coral-400',
  },
  pink: {
    bg: 'bg-pink-50 dark:bg-pink-900/20',
    text: 'text-pink-800 dark:text-pink-200',
    accent: 'text-pink-600 dark:text-pink-400',
    border: 'border-pink-200 dark:border-pink-800',
    badge: 'bg-pink-50 text-pink-800 dark:bg-pink-900/40 dark:text-pink-200',
    ring: 'ring-pink-400',
  },
  amber: {
    bg: 'bg-amber-50 dark:bg-amber-900/20',
    text: 'text-amber-800 dark:text-amber-200',
    accent: 'text-amber-600 dark:text-amber-400',
    border: 'border-amber-200 dark:border-amber-800',
    badge: 'bg-amber-50 text-amber-800 dark:bg-amber-900/40 dark:text-amber-200',
    ring: 'ring-amber-400',
  },
  emerald: {
    bg: 'bg-emerald-50 dark:bg-emerald-900/20',
    text: 'text-emerald-800 dark:text-emerald-200',
    accent: 'text-emerald-600 dark:text-emerald-400',
    border: 'border-emerald-200 dark:border-emerald-800',
    badge: 'bg-emerald-50 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200',
    ring: 'ring-emerald-400',
  },
}

export const ACCENT_HEX: Record<ColorKey, string> = {
  purple:  '#7F77DD',
  teal:    '#1D9E75',
  coral:   '#D85A30',
  pink:    '#D4537E',
  amber:   '#BA7517',
  emerald: '#639922',
}

export const WORD_COLORS = [
  'text-teal-600 dark:text-teal-400',
  'text-coral-600 dark:text-coral-400',
  'text-purple-600 dark:text-purple-400',
  'text-pink-600 dark:text-pink-400',
  'text-amber-600 dark:text-amber-400',
  'text-emerald-600 dark:text-emerald-400',
]

/** Colorize every Nth word in a string */
export function colorizeWords(text: string, step = 2): { word: string; colorClass: string }[] {
  return text.split(' ').map((word, i) => ({
    word,
    colorClass: i % step === 0 ? WORD_COLORS[Math.floor(i / step) % WORD_COLORS.length] : '',
  }))
}
